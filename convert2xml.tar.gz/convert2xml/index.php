<?php


require_once('convert2xmlPlugin.inc.php');
return new convert2xmlPlugin();
?>
